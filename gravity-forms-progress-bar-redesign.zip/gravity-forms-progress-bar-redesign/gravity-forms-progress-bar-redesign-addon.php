<?php
if ( class_exists( "GFForms" ) ) {
	GFForms::include_addon_framework();
	class AJ_GF_Progress_Bar_Redesign_AddOn  extends GFAddOn {
		protected $_version = "1.1";
		protected $_min_gravityforms_version = "2.0";
		protected $_slug = "aj_gf_progress_bar_redesign";
		protected $_full_path = __FILE__;
		protected $_title = "Gravity Forms - progress bar redesign";
		protected $_short_title = "Progress bar redesign";

		public function init(){
			parent::init();
            add_filter( 'gform_progress_bar', array( $this, 'aj_gform_progress_bar' ), 10, 3); 
        } // END init

		 
		function aj_gform_progress_bar( $progress_bar, $form, $confirmation_message ) {
    
             $form_id = $form['id'];
             $page = GFFormDisplay::get_current_page( $form_id );




             $progress_complete = false;
             $progress_bar = '';
             $page_count = GFFormDisplay::get_max_page_number( $form );
             $current_page = $page;
             $page_name = rgars( $form['pagination'], sprintf( 'pages/%d', $current_page - 1 ) );
             $page_name = $page_name;
             $style = $form['pagination']['style'];
             $color = $style == 'custom' ? " color:{$form['pagination']['color']};" : '';
             $bgcolor = $style == 'custom' ? " background-color:{$form['pagination']['backgroundColor']};" : '';

             if ( ! empty( $confirmation_message ) ) {
             $progress_complete = true;
             }
             //check admin setting for whether the progress bar should start at zero
             $start_at_zero = rgars( $form, 'pagination/display_progressbar_on_confirmation' );
             //check for filter
             $start_at_zero = apply_filters( '', $start_at_zero, $form );
             $progressbar_page_count = $start_at_zero ? $current_page - 1 : $current_page;
             $percent = ! $progress_complete ? floor( ( ( $progressbar_page_count ) / $page_count ) * 100 ) . '%' : '100%';
             $percent_number = ! $progress_complete ? floor( ( ( $progressbar_page_count ) / $page_count ) * 100 ) . '' : '100';

             if ( $progress_complete ) {
             $wrapper_css_class = GFCommon::get_browser_class() . ' gform_wrapper';

             //add on surrounding wrapper class when confirmation page
             $progress_bar = "<div class='{$wrapper_css_class}' id='gform_wrapper_$form_id'>";
                 $page_name = ! empty( $form['pagination']['progressbar_completion_text'] ) ? $form['pagination']['progressbar_completion_text'] : '';
                 }


                 $progress_bar .= "
                 <div id='gf_progressbar_wrapper_{$form_id}' class='gf_progressbar_wrapper'>
                     <h3 class='gf_progressbar_title'>"; 					                       
                         $progress_bar .= "{$page_name}";
						 $progress_bar .= "<span>STEP {$current_page} OF {$page_count}</span>";
                         $progress_bar .= "
                     </h3>
                     <div class='gf_progressbar'>
                         <div class='gf_progressbar_percentage percentbar_{$style} percentbar_{$percent_number}' style='width:{$percent};{$color}{$bgcolor}'><span>STEP {$current_page} OF {$page_count}</span></div>
                     </div>
                 </div>";
                 //close div for surrounding wrapper class when confirmation page
                 $progress_bar .= $progress_complete ? $confirmation_message . '</div>' : '';

             return $progress_bar;
             } // END form_submit_button

		 

		public function styles() {
			
			$version = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG || isset( $_GET['gform_debug'] ) ? mt_rand() : $this->_version;

			$styles = array(
				array(
					'handle'  => 'aj_progress_bar_redesign_css',
					'src'     => $this->get_base_url() . "/css/aj_progress_bar_redesign_css.css",
					'version' =>  $version,
					'media'   => 'screen',
					'enqueue' => array( array( $this, 'requires_stylesheet' ) ),
				),
			);

			return array_merge( parent::styles(), $styles );
		} // END styles

		public function requires_stylesheet( $form, $is_ajax ) {
			$progressbar_options = AJ_GF_Progress_Bar_Redesign::get_options();
			if ( rgar( $progressbar_options, 'includecss' ) && GFCommon::has_pages( $form ) && ! GFCommon::is_form_editor() && ! GFCommon::is_entry_detail() ) {
				return true;
			}

			return false;
		} // END requires_stylesheet
    }
    new AJ_GF_Progress_Bar_Redesign_AddOn();
}
