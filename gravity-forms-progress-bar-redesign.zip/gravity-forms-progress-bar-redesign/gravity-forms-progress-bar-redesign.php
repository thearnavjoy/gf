<?php
/*
Plugin Name: Gravity Forms - progress bar redesign
Description: Redesigns the progress bar on multi-page forms.
Version: 1.1
Author: AJ
Text Domain: gravity-forms-progress-bar-redesign
*/

if ( ! defined(  'ABSPATH' ) ) {
	die();
}
 

add_action( 'admin_notices', array( 'AJ_GF_Progress_Bar_Redesign', 'admin_warnings' ), 20 );

if ( !class_exists('AJ_GF_Progress_Bar_Redesign') ) {
    class AJ_GF_Progress_Bar_Redesign {

		private static $name = 'Gravity Forms - progress bar redesign';
		private static $slug = 'gravity-forms-progress-bar-redesign';

		/**
         * Construct the plugin object
         */
        public function __construct() {
			// register plugin functions through 'gform_loaded' -
			// this delays the registration until Gravity Forms has loaded, ensuring it does not run before Gravity Forms is available.
            add_action( 'gform_loaded', array( $this, 'register_actions' ) );

        } // END __construct

		/*
         * Register plugin functions
         */
		function register_actions() {
		// register actions
            if ( self::is_gravityforms_installed() ) {

				// addon framework
				require_once( plugin_dir_path( __FILE__ ).'gravity-forms-progress-bar-redesign-addon.php' );
 
			}
		} // END register_actions

		/*
		 *   Handles the plugin options.
		 *   Default values are stored in an array.
		 */
		public static function get_options() {
			$defaults = array(
				'includecss' => true,
			);
			$options = wp_parse_args( get_option( 'gravityformsaddon_gf_progress_bar_redesign' ), $defaults );
			return $options;
		} // END get_options 

		/*
         * Warning message if Gravity Forms is installed and enabled
         */
		public static function admin_warnings() {
			if ( !self::is_gravityforms_installed() ) {
				printf(
					'<div class="error"><h3>%s</h3><p>%s</p><p>%s</p></div>',
						__( 'Warning', 'gravity-forms-progress-bar-redesign' ),
						sprintf ( __( 'The plugin %s requires Gravity Forms to be installed.', 'gravity-forms-progress-bar-redesign' ), '<strong>'.self::$name.'</strong>' ),
						sprintf ( esc_html__( 'Please %sdownload the latest version of Gravity Forms%s and try again.', 'gravity-forms-progress-bar-redesign' ), '<a href="https://www.gravityforms.com/" target="_blank">', '</a>' )
					);
			}
		} // END admin_warnings

		/*
         * Check if GF is installed
         */
        private static function is_gravityforms_installed() {
			return class_exists( 'GFCommon' );
        } // END is_gravityforms_installed

	}
	$AJ_GF_Progress_Bar_Redesign = new AJ_GF_Progress_Bar_Redesign();
}
